'use strict';

module.exports = function(Datapegawai) {

};
